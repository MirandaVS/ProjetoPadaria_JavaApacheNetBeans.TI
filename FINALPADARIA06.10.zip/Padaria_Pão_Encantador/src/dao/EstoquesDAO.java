/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;


import beans.estoques;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 *
 * @author Jvdec
 */
public class EstoquesDAO {
    private Conexao conexao;
    private Connection conn;
    
    //Irei criar o CONSTRUTOR da classe. O construtor é executado
    //automaticamente sempre que um novo objeto é criado
    public EstoquesDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
        
    }
    //Esses códigos abaixo servem para colocar as informações na tabela
    public void inserir (estoques estoques){
      String sql = "INSERT INTO estoques(NomeEstoque, EmpresaEstoque, DataEstoque, TipoEstoque, PesoEstoque, SaborEstoque, PreçoEstoque, DisponibilidadeEstoque, CategoriaEstoque) VALUES "
              + "(?, ?, ?, ?, ?, ?, ?, ?, ?)"; //Os "?" são os parâmetros, ou seja, para cada coluna, preciso de um "?" para colocar um valor mais a frente.
        try{
    
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, estoques.getNomeEstoque());
        stmt.setString(2, estoques.getEmpresaEstoque());
        stmt.setString(3, estoques.getDataEstoque());
        stmt.setString(4, estoques.getTipoEstoque());
        stmt.setString(5, estoques.getPesoEstoque());
        stmt.setString(6, estoques.getSaborEstoque());
        stmt.setString(7, estoques.getPreçoEstoque());
        stmt.setInt(8, estoques.getDisponibilidadeEstoque());
        stmt.setString(9, estoques.getCategoriaEstoque());
        stmt.execute();
       
    }
    catch(Exception e){
        System.out.println("Erro ao inserir estoque: " + e.getMessage());
         }
    }
    
    public void editar (estoques estoques)
    {
        String sql = "UPDATE estoques SET NomeEstoque=?, EmpresaEstoque=?, DataEstoque=?, TipoEstoque=?, PesoEstoque=?, SaborEstoque=?, PreçoEstoque=?, DisponibilidadeEstoque=?, CategoriaEstoque=? WHERE id =?";
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, estoques.getNomeEstoque());
            stmt.setString(2, estoques.getEmpresaEstoque());
            stmt.setString(3, estoques.getDataEstoque());
            stmt.setString(4, estoques.getTipoEstoque());
            stmt.setString(5, estoques.getPesoEstoque());
            stmt.setString(6, estoques.getSaborEstoque());
            stmt.setString(7, estoques.getPreçoEstoque());
            stmt.setInt(8, estoques.getDisponibilidadeEstoque());
            stmt.setString(9, estoques.getCategoriaEstoque());
            stmt.setInt(10, estoques.getId());
            stmt.execute();
        } catch (Exception e) {
            System.out.println("Erro ao editar curso: " + e.getMessage()); 
        }
    }
    
    public void excluir(int Id)
    {
        String sql = "DELETE FROM estoques WHERE id = ?";
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1,Id);
            stmt.execute();
        } catch (Exception e) {
            System.out.println("Erro ao excluir curso: " + e.getMessage());
        }
    }        
    
    //Códigos abaixo servem para fazer a busca de determinado produto pelo id!
    public estoques getEstoques(int id)
    {
       String sql = "SELECT * FROM estoques WHERE id = ?";
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            estoques Estoques = new estoques();
            //Primeiramente, posiciona o ResultSet na primeira posição
            rs.first();
            Estoques.setId(id);
            Estoques.setNomeEstoque(rs.getString("NomeEstoque"));
            Estoques.setEmpresaEstoque(rs.getString("EmpresaEstoque"));
            Estoques.setDataEstoque(rs.getString("TipoEstoque"));
            Estoques.setTipoEstoque(rs.getString("TipoEstoque"));
            Estoques.setPesoEstoque(rs.getString("PesoEstoque"));
            Estoques.setSaborEstoque(rs.getString("SaborEstoque"));
            Estoques.setPreçoEstoque(rs.getString("PreçoEstoque"));
            Estoques.setDisponibilidadeEstoque(rs.getInt("DisponibilidadeEstoque"));
            Estoques.setCategoriaEstoque(rs.getString("CategoriaEstoque"));
            return Estoques;
            
        } catch (Exception e) {
            return null;
        }
    }
    
 }