/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import beans.estoques;
import beans.pães;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 *
 * @author Jvdec
 */
public class pãesDAO {
    private Conexao conexao;
    private Connection conn;
    
    //Irei criar o CONSTRUTOR da classe. O construtor é executado
    //automaticamente sempre que um novo objeto é criado
    public pãesDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();     
    
}
    //Esses códigos abaixo servem para colocar as informações na tabela
    public void inserir (pães pães){
      String sql = "INSERT INTO pães(NomePães, VencimentoPães, DataFabPães, TipoPães, QuantidadePães, SaborPães, GramasPães, NutrientesPães, PreçoPães) VALUES "
              + "(?, ?, ?, ?, ?, ?, ?, ?, ?)"; //Os "?" são os parâmetros, ou seja, para cada coluna, preciso de um "?" para colocar um valor mais a frente.
         try {
             PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, pães.getNomePães());
        stmt.setString(2, pães.getVencimentoPães());
        stmt.setString(3, pães.getDataFabPães());
        stmt.setString(4, pães.getTipoPães());
        stmt.setInt(5, pães.getQuantidadePães());
        stmt.setString(6, pães.getSaborPães());
        stmt.setString(7, pães.getGramasPães());
        stmt.setString(8, pães.getNutrientesPães());
        stmt.setString(9, pães.getPreçoPães());
        stmt.execute();  
        } 
        catch (Exception e){
            System.out.println("Erro ao inserir Pães" + e.getMessage());
        }
    }
    
    public void editar (pães pães)
    {
        String sql = "UPDATE pães SET NomePães=?, VencimentoPães=?, DataFabPães=?, TipoPães=?, QuantidadePães=?, SaborPães=?, GramasPães=?, NutrientesPães=?, PreçoPães=? WHERE id =?";
        try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, pães.getNomePães());
            stmt.setString(2, pães.getVencimentoPães());
            stmt.setString(3, pães.getDataFabPães());
            stmt.setString(4, pães.getTipoPães());
            stmt.setInt(5, pães.getQuantidadePães());
            stmt.setString(6, pães.getSaborPães());
            stmt.setString(7, pães.getGramasPães());
            stmt.setString(8, pães.getNutrientesPães());
            stmt.setString(9, pães.getPreçoPães());
            stmt.setInt(10, pães.getId());
            stmt.execute();
        } catch (Exception e) {
            System.out.println("Erro ao editar curso: " + e.getMessage()); 
        }
    }
    
public void excluir(int Id)
    {
        String sql = "DELETE FROM pães WHERE id = ?";
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1,Id);
            stmt.execute();
        } catch (Exception e) {
            System.out.println("Erro ao excluir curso: " + e.getMessage());
        }
    }  

 //Códigos abaixo servem para fazer a busca de determinado produto pelo id!
    public pães getPães(int id)
    {
       String sql = "SELECT * FROM estoques WHERE id = ?";
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            pães Pães = new pães();
            //Primeiramente, posiciona o ResultSet na primeira posição
            rs.first();
            Pães.setId(id);
            Pães.setNomePães(rs.getString("NomePães"));
            Pães.setVencimentoPães(rs.getString("VencimentoPães"));
            Pães.setDataFabPães(rs.getString("DataFabPães"));
            Pães.setTipoPães(rs.getString("TipoPães"));
            Pães.setQuantidadePães(rs.getInt("QuantidadePães"));
            Pães.setSaborPães(rs.getString("SaborPães"));
            Pães.setGramasPães(rs.getString("GramasPães"));
            Pães.setNutrientesPães(rs.getString("NutrientesPães"));
            Pães.setPreçoPães(rs.getString("PreçoPães"));
            return Pães;
            
        } catch (Exception e) {
            return null;
        }
    }
    
 }
    


