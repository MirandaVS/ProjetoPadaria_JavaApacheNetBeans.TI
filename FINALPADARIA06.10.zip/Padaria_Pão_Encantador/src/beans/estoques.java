/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author Jvdec
 */
public class estoques {
    private int id;
    private String NomeEstoque;
    private String EmpresaEstoque;
    private String DataEstoque;
    private String TipoEstoque;
    private String PesoEstoque;
    private String SaborEstoque;
    private String preçoEstoque;
    private int DisponibilidadeEstoque;
    private String CategoriaEstoque;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomeEstoque() {
        return NomeEstoque;
    }

    public void setNomeEstoque(String NomeEstoque) {
        this.NomeEstoque = NomeEstoque;
    }

    public String getEmpresaEstoque() {
        return EmpresaEstoque;
    }

    public void setEmpresaEstoque(String EmpresaEstoque) {
        this.EmpresaEstoque = EmpresaEstoque;
    }

    public String getDataEstoque() {
        return DataEstoque;
    }

    public void setDataEstoque(String DataEstoque) {
        this.DataEstoque = DataEstoque;
    }

    public String getTipoEstoque() {
        return TipoEstoque;
    }

    public void setTipoEstoque(String TipoEstoque) {
        this.TipoEstoque = TipoEstoque;
    }

    public String getPesoEstoque() {
        return PesoEstoque;
    }

    public void setPesoEstoque(String PesoEstoque) {
        this.PesoEstoque = PesoEstoque;
    }

    public String getSaborEstoque() {
        return SaborEstoque;
    }

    public void setSaborEstoque(String SaborEstoque) {
        this.SaborEstoque = SaborEstoque;
    }

    public String getPreçoEstoque() {
        return preçoEstoque;
    }

    public void setPreçoEstoque(String preçoEstoque) {
        this.preçoEstoque = preçoEstoque;
    }

    public int getDisponibilidadeEstoque() {
        return DisponibilidadeEstoque;
    }

    public void setDisponibilidadeEstoque(int DisponibilidadeEstoque) {
        this.DisponibilidadeEstoque = DisponibilidadeEstoque;
    }

    public String getCategoriaEstoque() {
        return CategoriaEstoque;
    }

    public void setCategoriaEstoque(String CategoriaEstoque) {
        this.CategoriaEstoque = CategoriaEstoque;
    }
    
    
    
}
