/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author Jvdec
 */
public class pães {
    private int id;
    private String NomePães;
    private String VencimentoPães;
    private String DataFabPães;
    private String TipoPães;
    private int QuantidadePães;
    private String SaborPães;
    private String GramasPães;
    private String NutrientesPães;
    private String PreçoPães;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomePães() {
        return NomePães;
    }

    public void setNomePães(String NomePães) {
        this.NomePães = NomePães;
    }

    public String getVencimentoPães() {
        return VencimentoPães;
    }

    public void setVencimentoPães(String VencimentoPães) {
        this.VencimentoPães = VencimentoPães;
    }

    public String getDataFabPães() {
        return DataFabPães;
    }

    public void setDataFabPães(String DataFabPães) {
        this.DataFabPães = DataFabPães;
    }

    public String getTipoPães() {
        return TipoPães;
    }

    public void setTipoPães(String TipoPães) {
        this.TipoPães = TipoPães;
    }

    public int getQuantidadePães() {
        return QuantidadePães;
    }

    public void setQuantidadePães(int QuantidadePães) {
        this.QuantidadePães = QuantidadePães;
    }

    public String getSaborPães() {
        return SaborPães;
    }

    public void setSaborPães(String SaborPães) {
        this.SaborPães = SaborPães;
    }

    public String getGramasPães() {
        return GramasPães;
    }

    public void setGramasPães(String GramasPães) {
        this.GramasPães = GramasPães;
    }

    public String getNutrientesPães() {
        return NutrientesPães;
    }

    public void setNutrientesPães(String NutrientesPães) {
        this.NutrientesPães = NutrientesPães;
    }

    public String getPreçoPães() {
        return PreçoPães;
    }

    public void setPreçoPães(String PreçoPães) {
        this.PreçoPães = PreçoPães;
    }
    
    
   
}
